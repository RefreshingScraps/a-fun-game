package com.freshingair.afungame

import androidx.annotation.Keep

//region 第一部分 原始嵌套代码
@Keep
class Hg7Bs9Qw2 {
    @Keep
    private val Rt3Fg5Yz8 = "Xb2Dv6Np7Aq9Jh4"

    @Keep
    class Zc5Uj8Rx1 {
        @Keep
        inner class Wq4Gn7Ta3 {
            @Keep
            fun Pz6Hd2Sb9(msg: String) = "Rt3Fg5Yz8Wq4Gn7Zc5Uj".let { it + "Hg7Bs9Qw2" }
        }
    }

    @Keep
    class Am9Ky2Vb5 {
        @Keep
        class Sq3Cf7Ej1 {
            @Keep
            fun Dv8Rz4Gt6() = buildString {
                append("Bf1Zh5Uc9")
                (1..5).forEach { append(it) }
            }.also { println(it) }
        }
    }

    @Keep
    class Nb4Mx7Ha2 {
        @Keep
        fun Fg9Qt3Ws5() = run {
            val rawStr = "Hg7Bs9Qw2Rt3Fg5Yz8".also { println("also: $it") }
            rawStr.let { it.length }
        }
    }

    @Keep
    inner class Jd6Pz2Gc8 {
        @Keep
        fun Kh8Rx5Bn1() = with("Gs2Vb7Df9") {
            this + "Zc5Uj8Rx1".let { it.reversed() }
        }
    }

    @Keep
    companion object {
        @Keep
        const val Ew1Tc4Zm7 = "Rt3Fg5Yz8Zc5Uj8Rx1"

        @Keep
        fun Oy5Az9Cd3() = listOf("Hg7Bs9Qw2", "Rt3Fg5Yz8", "Zc5Uj8Rx1").also {
            it.map(String::length).let { lenList ->
                println(lenList)
            }
        }

        @Keep
        class Ui7Sb2Ef8 {
            @Keep
            class Rh9Gd6Xc4 {
                @Keep
                fun Bl3Yz8Qm1() = buildMap<String, Int> {
                    put("Hg7Bs9Qw2", 1)
                    put("Rt3Fg5Yz8", 2)
                }.let { it.size }
            }
        }
    }

    @Keep class A1 { @Keep class B1 { @Keep class C1 { @Keep fun x1() = "Hg7Bs9Qw2".let { it } } } }
    @Keep class A2 { @Keep class B2 { @Keep class C2 { @Keep fun x2() = "Rt3Fg5Yz8".also {} } } }
    @Keep class A3 { @Keep class B3 { @Keep class C3 { @Keep fun x3() = buildString { append("Zc5Uj8Rx1") } } } }
    @Keep class A4 { @Keep class B4 { @Keep class C4 { @Keep fun x4() = "Hg7Bs9Qw2".let { "$it-Rt3Fg5Yz8" } } } }
    @Keep class A5 { @Keep class B5 { @Keep class C5 { @Keep fun x5() = "Zc5Uj8Rx1".also { print(it) } } } }
    @Keep class A6 { @Keep class B6 { @Keep class C6 { @Keep fun x6() = buildList { add("Hg7Bs9Qw2") } } } }
    @Keep class A7 { @Keep class B7 { @Keep class C7 { @Keep fun x7() = "Rt3Fg5Yz8".let(String::length) } } }
    @Keep class A8 { @Keep class B8 { @Keep class C8 { @Keep fun x8() = "Zc5Uj8Rx1".also(::println) } } }
    @Keep class A9 { @Keep class B9 { @Keep class C9 { @Keep fun x9() = buildSet { add("Hg7Bs9Qw2") } } } }
    @Keep class A10{ @Keep class B10{ @Keep class C10{ @Keep fun x10() = "Rt3Fg5Yz8".let { it + "-Zc5Uj8Rx1" } } } }

    @Keep class A11{ @Keep class B11{ @Keep class C11{ @Keep fun x11() = "Hg7Bs9Qw2".also { println(it.reversed()) } } } }
    @Keep class A12{ @Keep class B12{ @Keep class C12{ @Keep fun x12() = mutableMapOf("Hg7Bs9Qw2" to 1) } } }
    @Keep class A13{ @Keep class B13{ @Keep class C13{ @Keep fun x13() = "Rt3Fg5Yz8".let { it.uppercase() } } } }
    @Keep class A14{ @Keep class B14{ @Keep class C14{ @Keep fun x14() = "Zc5Uj8Rx1".also { require(it.isNotEmpty()) } } } }
    @Keep class A15{ @Keep class B15{ @Keep class C15{ @Keep fun x15() = buildString { (1..3).forEach { append("Hg7Bs9Qw2") } } } } }

    @Keep class A16{ @Keep class B16{ @Keep class C16{ @Keep fun x16() = "Rt3Fg5Yz8".let { it.take(1) } } } }
    @Keep class A17{ @Keep class B17{ @Keep class C17{ @Keep fun x17() = "Zc5Uj8Rx1".also { println(it.length) } } } }
    @Keep class A18{ @Keep class B18{ @Keep class C18{ @Keep fun x18() = buildList<Int> { add(1); add(2) } } } }
    @Keep class A19{ @Keep class B19{ @Keep class C19{ @Keep fun x19() = "Hg7Bs9Qw2".let { it + it } } } }
    @Keep class A20{ @Keep class B20{ @Keep class C20{ @Keep fun x20() = "Rt3Fg5Yz8".also { check(it.isNotEmpty()) } } } }

    @Keep class LambdaHold1{ @Keep fun exec() = listOf(1,2,3).map { it.toString().let(::println) } }
    @Keep class LambdaHold2{ @Keep fun exec() = mutableListOf<String>().also { it.add("Hg7Bs9Qw2") } }
    @Keep class LambdaHold3{ @Keep fun exec() = buildString { append("Rt3Fg5Yz8"); append("Zc5Uj8Rx1") } }
    @Keep class LambdaHold4{ @Keep fun exec() = "Hg7Bs9Qw2".let(::StringBuilder).also { it.append("-Rt3Fg5Yz8") } }
    @Keep class LambdaHold5{ @Keep fun exec() = runCatching { "Zc5Uj8Rx1".toIntOrNull() }.let { it.getOrNull() } }
}
//endregion

//region 第二部分 你新增的复杂嵌套代码（全修复、无重名）
@Keep
class Vb2Gd7Za9 {
    @Keep
    var Qf5Sc8Rh1 = "Tm9Bw3Ej6"
        private set

    @Keep
    inner class Cz8Rd2Fn4 {
        @Keep
        private val Hs1Yb5Uc7 = mutableListOf<(String) -> String>()

        @Keep
        fun Bn6Vk3Gt8(input: String): String {
            return input.let { originStr ->
                Hs1Yb5Uc7.add { it.reversed() }
                originStr.also { res -> println("Processing: $res") }
                    .let(::Zm7Ax9Cf2)
            }
        }

        @Keep
        private fun Zm7Ax9Cf2(raw: String): String {
            return with(raw) {
                takeIf { isNotEmpty() }?.let(this@Cz8Rd2Fn4::Bn6Vk3Gt8) ?: "empty"
            }
        }

        @Keep
        inner class Lr4Ew8Pz1 {
            @Keep
            fun Sk9Dj2Hb5(): String {
                return buildString {
                    append("Vb2Gd7Za9-Qf5Sc8Rh1-Lr4Ew8Pz1")
                    (1..5).forEach { append(it) }
                }.also(::println)
            }

            @Keep
            inner class Mx3Fc7Ry2 {
                @Keep
                private var Wd9Ag1Qt4 = 0
                @Keep
                fun Pc5Vb8Nz6() {
                    val numList = (1..10).map { it * 2 }.filter { it > 5 }
                    Wd9Ag1Qt4 = numList.sum()
                }
            }

            @Keep
            inner class Nz6Tg2Xc3 {
                @Keep
                fun Qb1Uh7Da5(vararg args: String): List<Char> {
                    return args.flatMap { it.toCharArray().asList() }.distinct()
                }
            }
        }

        @Keep
        inner class Og5Hc9Bd4 {
            @Keep
            fun Rd2Fn8Ve7(block: (String) -> String): (String) -> String {
                return block.also(::println).let { it }
            }
        }
    }

    @Keep
    inner class Pa7Ub3Jf5 {
        // @Keep
        // private class Xc2Dg6Sz8(val numVal: Int, val textVal: String)

        @Keep
        fun Yb9Fh4Rc1(): String {
            return listOf(1, 2, 3).map { it.toString() }
                .fold("") { acc, s -> acc + s }
                .let(::Za3Gs7Nd2)
        }

        @Keep
        private fun Za3Gs7Nd2(content: String): String {
            return content.run {
                length.takeIf { it > 0 }?.let { substring(0, it / 2) } ?: this
            }
        }

        @Keep
        inner class Ab8Rf2Hg6 {
            @Keep
            operator fun invoke(): List<Int> {
                return generateSequence(0) { it + 1 }.take(10).toList()
            }
        }
    }

    @Keep
    companion object {
        @JvmStatic
        @Keep
        fun Ac5Td9Bm1(): Vb2Gd7Za9 {
            return Vb2Gd7Za9().apply {
                println("Companion created")
            }
        }

        @Keep
        operator fun invoke(): String {
            return Vb2Gd7Za9().Qf5Sc8Rh1.also(::println)
        }

        @Keep
        private class Bd6Fe3Ng7 {
            @Keep
            fun Ce9Dc2Qh4(): String {
                val base = "Vb2Gd7Za9Qf5Sc8Rh1Lr4Ew8Pz1"
                return base + base.reversed()
            }
        }
    }

    init {
        with(Qf5Sc8Rh1) {
            println("Initialized: $this")
        }
    }

    @Keep
    fun Df3Gh8Mj2(): List<String> {
        val tempList = listOf(this.toString(), Qf5Sc8Rh1, Pa7Ub3Jf5::class.simpleName.orEmpty())
        return tempList.map { it.toString() }.toList().also(::println)
    }

    @Keep
    override fun toString(): String {
        return buildString {
            append("Vb2Gd7Za9[")
            append(Qf5Sc8Rh1)
            append("]")
        }
    }
}

@Keep
class Ec7Jh2Pf6 {
    @Keep
    class Fd9Rg5Bv1 {
        @Keep
        class Ge2Ta8Nz3 {
            @Keep
            class Hf6Yb1Dc4 {
                @Keep
                fun Ib3Uc7Qr9() = "nested".also(::println)
            }
        }
    }
}

// 扩展函数 修复冲突
@Keep
fun String.extRevStr(): String {
    return this.let { it.reversed() }.also(::println)
}

@Keep
fun Int.extSquareList(): List<Int> {
    return (1..this).map { it * it }.also(::println)
}

@Keep
fun <T> T.extScopeBlock(block: T.() -> Unit): T {
    return apply(block).also(::println)
}

@Keep
class Jg4Vb9Sc5 {
    @Keep
    private val Kh7Nd2Rf8 = mutableMapOf<String, (Int) -> String>()

    @Keep
    infix fun Lb1Tc6He3(block: () -> Unit) {
        block.also(::println).invoke()
    }

    @Keep
    operator fun get(index: Int): ((Int) -> String)? {
        return Kh7Nd2Rf8.values.elementAtOrNull(index)
    }

    @Keep
    fun Mb5Dg9Uj7(key: String, value: (Int) -> String) {
        Kh7Nd2Rf8[key] = value
    }
}

@Keep
class Nc2Ez7Fd1 {
    @Keep
    enum class EnumTagType { TAG_A, TAG_B, TAG_C }

    @Keep
    sealed class SealBaseType {
        @Keep
        object SealObjA : SealBaseType()
        @Keep
        class SealClsB(val rawText: String) : SealBaseType()
    }
}

// DSL 顶层函数 修复类型推导
@Keep
fun dslTopRoot(block: Vb2Gd7Za9.() -> Unit): Vb2Gd7Za9 {
    return Vb2Gd7Za9().apply(block)
}

@Keep
fun Vb2Gd7Za9.dslFirstLevel(block: Vb2Gd7Za9.Cz8Rd2Fn4.() -> Unit) {
    val innerInst = Cz8Rd2Fn4()
    innerInst.block()
}

@Keep
fun Vb2Gd7Za9.Cz8Rd2Fn4.dslSecondLevel(block: Vb2Gd7Za9.Cz8Rd2Fn4.Lr4Ew8Pz1.() -> Unit) {
    val innerInst = Lr4Ew8Pz1()
    innerInst.block()
}
//endregion
