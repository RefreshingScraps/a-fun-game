package com.freshingair.afungame;

import androidx.annotation.Keep;

import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.stream.*;
import java.lang.annotation.*;
import java.lang.reflect.*;

@Keep
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD})
@interface A7s9G2k {
    @Keep
    String B5d8R7f() default "C3x2J6h";
}

@Keep
@A7s9G2k(B5d8R7f = "D9b4N1m")
class E2g5P8z {
    static {
        System.out.println("static init E2g5P8z");
    }

    @Keep
    class F6j3Q5w {
        @Keep
        class G1r7T4v {
            @Keep
            class H8k2U9b {
                @Keep
                class I4n6V3c {
                    @Keep
                    void J5m8W7d() {
                        System.out.println("deep nested");
                    }
                }
            }
        }
    }

    @Keep
    interface K9p1X2e {
        @Keep
        default void L3q7Y5f() {
            System.out.println("interface default");
        }
    }

    @Keep
    enum M6r4Z8g {
        N2s5A3h, O7t1B6i, P3u9C4j, Q8v2D7k;

        static {
            System.out.println("enum static");
        }
    }
}

@Keep
public class T2x7Yq4Lp9Nw3Rc6ZmL1 {

    @Keep
    static class R4w6E9l implements E2g5P8z.K9p1X2e {
        {
            System.out.println("instance init R4w6E9l");
        }

        @Keep
        static class S9x3F2m {
            @Keep
            static class T5y7G6n {
                @Keep
                static class U1z4H8o {
                    @Keep
                    String V6a9I3p = "W2b5J7q";

                    @Keep
                    static class X7c1K4r {
                        @Keep
                        static class Y3d8L9s {
                            @Keep
                            static class Z8e2M5t {
                                @Keep
                                Runnable A4f6N7u = () -> System.out.println("lambda");
                            }
                        }
                    }
                }
            }
        }
    }

    @Keep
    static class B9g3O2v {
        @Keep
        static Map<String, Object> C5h7P6w = new HashMap<>() {{
            put("D1i4Q8x", "E6j9R3y");
            put("F2k5S7z", "G7l1T4a");
            put("H3m8U9b", "I8n2V5c");
            put("J4o6W7d", new Object() {{
                System.out.println("double brace in map");
            }});
        }};
    }

    public static void main(String[] args) {
        // 匿名类1
        Runnable K9p3X2e = new Runnable() {
            {
                System.out.println("anonymous init 1");
            }
            @Override
            public void run() {
                System.out.println("run K9p3X2e");
            }
        };

        // 匿名类2 - 带双花括号
        List<String> L5q7Y6f = new ArrayList<>() {{
            add("M1r4Z9g");
            add("N6s2A3h");
            add("O2t7B8i");
            add("P7u3C4j");
            add("Q3v8D9k");
            System.out.println("double brace ArrayList");
        }};

        // 匿名类3 - Thread子类
        Thread R8w4E2l = new Thread() {
            {
                setName("S4x9F7m");
            }
            @Override
            public void run() {
                System.out.println(getName());
            }
        };

        // Lambda表达式（产生invokedynamic，运行时生成类）
        Consumer<String> T9y5G3n = s -> System.out.println(s);
        Function<Integer, String> U4z1H8o = i -> "value:" + i;
        Predicate<String> V7a6I2p = s -> s.length() > 3;
        Supplier<Object> W2b9J7q = () -> new Object() {
            {
                System.out.println("supplier anonymous");
            }
        };
        BiFunction<String, Integer, String> X6c3K4r = (s, i) -> s + i;

        // 方法引用
        Consumer<String> Y9d7L2s = System.out::println;

        // 匿名类4 - 带双花括号的HashMap
        Map<Integer, String> Z4e8M5t = new LinkedHashMap<>() {{
            put(1, "A5f2N9u");
            put(2, "B9g7O3v");
            put(3, "C3h4P6w");
            put(4, "D8i9Q1x");
        }};

        // 局部类
        @Keep
        class E2j5R7y {
            @Keep
            String F7k1S3z = "G3l6T8a";

            @Keep
            class H8m2U4b {
                @Keep
                class I4n7V9c {
                    @Keep
                    void J9o3W5d() {
                        // 匿名类5
                        Comparable<String> K5p8X2e = new Comparable<>() {
                            @Override
                            public int compareTo(String o) {
                                return 0;
                            }
                        };
                    }
                }
            }
        }

        // Enum匿名类体
        @Keep
        enum L6q9Y3f {
            M2r5Z7g {
                @Override
                public String toString() {
                    return "enum body M2r5Z7g";
                }
            },
            N7s1A4h {
                @Override
                public String toString() {
                    return "enum body N7s1A4h";
                }
            };
        }

        // 多接口实现匿名类
        Object O3t6B9i = new Runnable() {
            {
                System.out.println("multi-impl anonymous");
            }
            public void run() {}
            public String toString() {
                return "P8u2C5j";
            }
        };

        // 使用Stream产生内部类
        Arrays.asList("Q4v7D3k", "R9w3E8l", "S5x8F2m").stream()
                .map(s -> s + "T1y4G6n")
                .filter(s -> !s.isEmpty())
                .forEach(new Consumer<String>() {
                    int count = 0;
                    {
                        System.out.println("stream consumer init");
                    }
                    @Override
                    public void accept(String s) {
                        count++;
                        System.out.println(s);
                    }
                });

        // CompletableFuture产生内部类
        CompletableFuture.supplyAsync(() -> "U6z9H1o")
                .thenApply(s -> s + "V2a5I7p")
                .thenAccept(new Consumer<String>() {
                    {
                        System.out.println("future consumer init");
                    }
                    @Override
                    public void accept(String s) {
                        System.out.println(s);
                    }
                });

        System.out.println("Main finished");
    }

    @Keep
    static class W7b3J8q {
        @Keep
        static class X3c7K2r {
            @Keep
            static class Y8d4L9s {
                {
                    System.out.println("nested static init");
                }
            }
        }
    }
}

// 外部接口
@Keep
interface Z9e5M4t {
    @Keep
    interface A4f9N7u {
        @Keep
        interface B5g2O3v {
            @Keep
            default void C9h6P8w() {
                System.out.println("nested interface default");
            }
        }
    }
}

// 外部抽象类
@Keep
abstract class D3i7Q4x {
    @Keep
    abstract void E8j2R9y();

    @Keep
    static class F4k6S3z {
        @Keep
        class G9l1T7a {
            @Keep
            class H5m8U2b {
                @Keep
                String I1n4V6c = "J6o9W3d";
            }
        }
    }
}

// 外部枚举
@Keep
enum K2p7X5e {
    L7q3Y9f, M3r8Z4g, N8s2A7h;

    @Keep
    static class O4t6B1i {
        @Keep
        class P9u1C5j {
            @Keep
            class Q5v7D2k {
                @Keep
                void R1w4E8l() {
                    new Thread() {
                        @Override
                        public void run() {
                            System.out.println("enum static class thread");
                        }
                    }.start();
                }
            }
        }
    }
}
